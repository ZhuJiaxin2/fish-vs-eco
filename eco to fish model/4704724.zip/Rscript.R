#R script for Bayesian hierarchical logistic regression examining percent male in sea lamprey for lentic and stream environments
#Analyses associated with the manuscript 
#Johnson, N.S., W.D. Swink, and T.O. Brenden. In press. Field study suggests that sex determination in 
sea lamprey is directly influenced by larval growth rate. Proceedings of the Royal Society B.
#Code is provided without any expressed or implied warranty.
#Code last modified by T. Brenden (MSU) and N. Johnson (USGS) - 02/28/2017

#Loading necessary libararies
library(R2jags)
library(runjags)

#Reading in data and converting numeric location identifier into a factor variable
ratio<-read.table("data.csv", sep=",", header=T)
ratio$Location<-as.factor(ratio$Location)

#Creating a 2x2 identity matrix as a vague prior for the scale paramter for a Wishart distribution
R <- matrix(0,nrow=2,ncol=2)
diag(R)<-1.0

#Creating a list overdipsersed initialization values for conducting the MCMC analyses
inits <- list(list(parms.lentic=c(-3,1),parms.lotic=c(-3,1),beta=c(0,0,0,0,0,0,0,0),beta1=c(0,0,0,0,0,0,0,0),sigma.intercept=0.01,sigma.slope=0.01),
              list(parms.lentic=c(0,0),parms.lotic=c(0,0),beta=c(0,0,0,0,0,0,0,0),beta1=c(0,0,0,0,0,0,0,0),sigma.intercept=1.2,sigma.slope=1.2),
              list(parms.lentic=c(3,-1),parms.lotic=c(3,-1),beta=c(0,0,0,0,0,0,0,0),beta1=c(0,0,0,0,0,0,0,0),sigma.intercept=10,sigma.slope=10))

#Creating a list of data that will be used in fitting the hierarchical model
lamprey.data <- list(Years=ratio$Years,males=ratio$Male,streams=ratio$Location,N=nrow(ratio),R=R,mn=c(0,0))

#Identifying parameters and derived variables for which posterior probability distributions will be characterized
lamprey.parms <- c("parms.lentic","parms.lotic","sigma.intercept","sigma.slope","predicted","lentic","lotic","beta","beta1")

#Specifying the JAGS code for fitting the model
lamprey.model <- function() {

#Specifying the priors and hyperpriors for model parameters
TAU[1:2,1:2] ~ dwish(R[1:2,1:2],3)
TAU2[1:2,1:2] ~ dwish(R[1:2,1:2],3) 
parms.lentic[1:2] ~ dmnorm(mn,TAU)
parms.lotic[1:2] ~ dmnorm(mn,TAU2)
sigma.intercept ~ dunif(0,100)
tau.intercept <- 1/(sigma.intercept*sigma.intercept)
sigma.slope ~ dunif(0,100)
tau.slope <- 1/(sigma.slope*sigma.slope)

#Specifying location-specific parameters for analyzing percent male for lentic systems
for (j in 1 : 3) {
      beta[j] ~ dnorm(parms.lentic[1],tau.intercept)
   	beta1[j] ~ dnorm(parms.lentic[2],tau.slope)
} 
#Specifying location-specific parameters for analyzing percent male for river systems
for (j in 4 : 8) {
      beta[j] ~ dnorm(parms.lotic[1],tau.intercept)
   	beta1[j] ~ dnorm(parms.lotic[2],tau.slope)
} 

#Specifying the model likelihood
for (i in 1:N) {
	logit(p[i]) <- beta[streams[i]]+beta1[streams[i]]*Years[i]
	males[i]~dbern(p[i])
}

#Predicting percent male for each location from 0 to 7 years post tagging
for (k in 1:7) {
	logit(lentic[k])=parms.lentic[1]+parms.lentic[2]*(k-1)
	logit(lotic[k])=parms.lotic[1]+parms.lotic[2]*(k-1)
	logit(predicted[k,1])=beta[1]+beta1[1]*(k-1)
	logit(predicted[k,2])=beta[2]+beta1[2]*(k-1)
	logit(predicted[k,3])=beta[3]+beta1[3]*(k-1)
	logit(predicted[k,4])=beta[4]+beta1[4]*(k-1)
	logit(predicted[k,5])=beta[5]+beta1[5]*(k-1)
	logit(predicted[k,6])=beta[6]+beta1[6]*(k-1)
	logit(predicted[k,7])=beta[7]+beta1[7]*(k-1)
	logit(predicted[k,8])=beta[8]+beta1[8]*(k-1)
}
}

#Specifying the random seed for reproducability
set.seed(302563)

#Running the JAGS model, printing results, and converting results to an .mcmc object
jags.model<- jags(lamprey.data,inits=inits,parameters.to.save=lamprey.parms,n.chains=3,n.iter=2000000,n.burnin=1000000,n.thin=100,model.file=lamprey.model)
print(jags.model)
mcmc.model<-as.mcmc(jags.model)

#Changing the plotting parameters and generating traceplots and density plots 
par(mar=c(2.5,3,2,1),mfrow=c(3,3))
traceplot(mcmc.model)
densplot(mcmc.model)

#Calculating scale reduction factor to evaluate whether the 3 chains have converged on similar distributions
gelman.diag(mcmc.model)

#Combining the saved iterations from the 3 chains into a single chain
mcmc.combined <- combine.mcmc(mcmc.model)

#Obtaining medians from the saved MCMC chain
mcmc.summary<-summary(mcmc.combined)
mcmc.summary

#Obtaining highest posterior density intervals from the saved MCMC chain
mcmc.HPD<-HPDinterval(mcmc.combined)
mcmc.HPD

#Calculating how likely that the probability male will be greater in lentic versus stream environments from the saved MCMC chain for different time periods
year0<-mcmc.combined[,18]>mcmc.combined[,25]
sum(year0)/length(year0)
year1<-mcmc.combined[,19]>mcmc.combined[,26]
sum(year1)/length(year1)
year2<-mcmc.combined[,20]>mcmc.combined[,27]
sum(year2)/length(year2)
year3<-mcmc.combined[,21]>mcmc.combined[,28]
sum(year3)/length(year3)
year4<-mcmc.combined[,22]>mcmc.combined[,29]
sum(year4)/length(year4)
year5<-mcmc.combined[,23]>mcmc.combined[,30]
sum(year5)/length(year5)
year6<-mcmc.combined[,24]>mcmc.combined[,31]
sum(year6)/length(year6)
